﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Ganini.Lib;


public partial class MasterPage3 : System.Web.UI.MasterPage
{
 #region Declaration
    ProcessBus Bus = new ProcessBus();
    EmployeeMasterMsg emp = new EmployeeMasterMsg();
    List<ProgramMsg> ProgramList = new List<ProgramMsg>();
    BaseClass AccessBaseClass = new BaseClass();
    public static string currValue="1";
    public static string wcurVal = "1";
    public static string Viwstateval = "1";
    int MenuCount = 0;
//    string UserName, HitCounter, Id, LogofDateTime, PlantId, PlantName = null;
    string MainMenu, MainSubMenu = null;
    string WMainMenu, WMainSubMenu, WSubMenu = null;
    MenuItem Menu1 = new MenuItem();
    MenuItem Menu2 = new MenuItem();
    MenuItem Menu3 = new MenuItem();
    MenuItem Menu4 = new MenuItem();
    MenuItem Menu5 = new MenuItem();
    MenuItem Menu6 = new MenuItem();
    MenuItem Menu7 = new MenuItem();
    MenuItem Menu8 = new MenuItem();
    MenuItem Menu9 = new MenuItem();
   private DataTable dtMenu
    {
        get
        {
            object objdt = ViewState["vsDt"];
            return (DataTable)objdt;
        }
        set
        {
            ViewState["vsDt"] = value;
        }
    }
#endregion
    #region Events and Operations
    protected void Page_Load(object sender, EventArgs e)
    {
        Uri u = Request.Url;
        if (AccessBaseClass.EmployeeName == string.Empty)
        {
            Response.Redirect(string.Format("~/Login.aspx?IsSessionTimeOutFlag={0}", "Y"));
        }
        lbluname.Text = AccessBaseClass.EmployeeName;
        lblDate.Text = Convert.ToString(System.DateTime.Now.ToString("dd-MMM-yyyy hh:mm"));
        lblVersionNumber.Text = Config.GetAppsetting("VERSION");
        //lblHeading.Text = lblHeading.Text + " - "+ lblVersionName.Text + lblVersionNumber.Text; //scs 230501 vj wants version in the top
        //Id = AccessBaseClass.UserId;
        //UserName = AccessBaseClass.UserFullName;
        //HitCounter = AccessBaseClass.HitCounter;
        //PlantId = AccessBaseClass.PlantId;
        //PlantName = AccessBaseClass.PlantName;
       if (!Page.IsPostBack)
        {
            Session["Sess1curVal"] = "";
            emp.EmployeeCode = AccessBaseClass.EmployeeCode;
            ProgramList = Bus.AdmUserAccessProgramsSelect(emp);
            AccessBaseClass.ProgramMsgList = ProgramList;
            //DataTable dt = new DataTable();

            //dt.Columns.Add("MainMenu");
            //dt.Columns.Add("ProgramAccessPath");
            //dt.Columns.Add("URL");
            //foreach (var item in ProgramList)
            //{
            //    var row = dt.NewRow();

            //    row["Name"] = item.MainMenu;
            //    row["Price"] = item.ProgramAccessPath;
            //    row["URL"] = item.;

            //    dt.Rows.Add(row);
            //}

            //dtMenu = ProgramList;
            LoadMenu(ProgramList);
        }
        //if (currValue != "1")
        if (AccessBaseClass.SessionVar1 != "")
        {
            Session["Sess1curVal"] = wcurVal;
            Session["Sess3curVal"] = wcurVal;
            AccessBaseClass.SessionVar1 = wcurVal;
        }
            //dtMenu = Bus.GetMenuItems(Id);
            //LoadMenu(dtMenu);
    }

    #region MenuLoading
    private void LoadMenu(List<ProgramMsg> ProgramList)
    {
        
        //foreach (DataRow dr in dtMenu.Rows)
        foreach (ProgramMsg dr in ProgramList)
        {
            WMainMenu = dr.MainMenu.ToString();
            WSubMenu = dr.SubMenu.ToString();
            WMainSubMenu = WMainMenu + WSubMenu;
            #region NewMainMenu
            if (MainMenu != dr.MainMenu.ToString()) // This is a new menu  //Add MainMenu Item
            {
                
                MenuCount = MenuCount + 1;
                LoadMainMenuName(MenuCount, WMainMenu);   // Load MainMenu Name Based on MenuCount
                if (WMainSubMenu != WMainMenu) // There is a submenu item in this main menu
                {
                    MenuItem Sub = new MenuItem();
                    Sub.Text = WSubMenu;
                    List<ProgramMsg> drsubMenu = new List<ProgramMsg>();
                    drsubMenu = (from drsub in ProgramList  where drsub.MainMenu==WMainMenu && drsub.SubMenu==WSubMenu select drsub).ToList();
                    //foreach (DataRow drSubTrans in dtMenu.Select("MainMenu ='" + WMainMenu + "' and SubMenu = '" + WSubMenu + "'"))
                    foreach( ProgramMsg drSubTrans in drsubMenu)
                    {
                        MenuItem SubSubMenu = new MenuItem();
                        SubSubMenu.Text = drSubTrans.ChildMenu.ToString();
                        SubSubMenu.NavigateUrl = drSubTrans.ProgramAccessPath.ToString();
                        Sub.ChildItems.Add(SubSubMenu);
                    }
                    MainMenu = WMainMenu;
                    MainSubMenu = WMainSubMenu;
                    LoadSubMenu(MenuCount, Sub); // Load SubMenu Under the MainMenu Depending on MenuCount 
                }
                else //There's no SubMenu hence the submenu becomes the child menu for hyper linking
                {
                    List<ProgramMsg> drsubMenu = new List<ProgramMsg>();
                    drsubMenu = (from drsub in ProgramList where drsub.MainMenu == WMainMenu select drsub).ToList();
                    //foreach (DataRow drSubTrans in dtMenu.Select("MainMenu = '" + WMainMenu + "'"))
                    foreach (ProgramMsg drSubTrans in drsubMenu)
                    {
                        MenuItem SubSubMenu = new MenuItem();
                        SubSubMenu.Text = drSubTrans.ChildMenu.ToString();
                        SubSubMenu.NavigateUrl = drSubTrans.ProgramAccessPath.ToString();
                        LoadSubMenu(MenuCount, SubSubMenu); // Load SubSubMenu Under the MainMenu Depending on MenuCount
                    }
                    MainMenu = WMainMenu;
                    MainSubMenu = WMainSubMenu;
                }
            }
            #endregion
            #region Submenu
            else // MainMenu Remains Same
            {
                //If there is a new submenu for same main menu add it else SKIP
                if (MainSubMenu != WMainSubMenu) // There is a new Submenu hence proceed
                {
                    if (WMainSubMenu != WMainMenu) // There is a submenu item in this main menu
                    {
                        List<ProgramMsg> drsubMenu = new List<ProgramMsg>();
                        MenuItem Sub = new MenuItem();
                        Sub.Text = WSubMenu;
                        drsubMenu = (from drsub in ProgramList where drsub.MainMenu == WMainMenu && drsub.SubMenu == WSubMenu select drsub).ToList();
                        //foreach (DataRow drSub in dtMenu.Select("MainMenu ='" + WMainMenu + "' and SubMenu = '" + WSubMenu + "'"))
                        foreach (ProgramMsg drSub in drsubMenu)
                        {
                            MenuItem SubSubMenu = new MenuItem();
                            SubSubMenu.Text = drSub.ChildMenu.ToString();
                            SubSubMenu.NavigateUrl = drSub.ProgramAccessPath.ToString();
                            Sub.ChildItems.Add(SubSubMenu);
                        }
                        MainMenu = WMainMenu;
                        MainSubMenu = WMainSubMenu;
                        LoadSubMenu(MenuCount, Sub); // Load SubMenu Under the MainMenu Depending on MenuCount
                    }
                    else  // There is no submenu item in this main menu
                    {
                        List<ProgramMsg> drsubMenu = new List<ProgramMsg>();
                        drsubMenu = (from drsub in ProgramList where drsub.MainMenu == WMainMenu && drsub.SubMenu == WSubMenu select drsub).ToList();
                        //foreach (DataRow drSub in dtMenu.Select("MainMenu = '" + WMainMenu + "'"))
                        foreach (ProgramMsg drSub in drsubMenu)
                        {
                            MenuItem SubSubMenu = new MenuItem();
                            SubSubMenu.Text = drSub.ChildMenu.ToString();
                            SubSubMenu.NavigateUrl = drSub.ProgramAccessPath.ToString();
                            LoadSubMenu(MenuCount, SubSubMenu); // Load SubSubMenu Under the MainMenu Depending on MenuCount  
                        }
                        MainMenu = WMainMenu;
                        MainSubMenu = WMainSubMenu;
                    }
                }
                else
                {
                    //Skip
                }
            }
            #endregion
        }
        for (int i = 1; i <= MenuCount; i++)
        {
            if (i == 1)
            {
                mnuMainMenu.Items.Add(Menu1);
            }
            else if (i == 2)
            {
                mnuMainMenu.Items.Add(Menu2);
            }
            else if (i == 3)
            {
                mnuMainMenu.Items.Add(Menu3);
            }
            else if (i == 4)
            {
                mnuMainMenu.Items.Add(Menu4);
            }
            else if (i == 5)
            {
                mnuMainMenu.Items.Add(Menu5);
            }
            else if (i == 6)
            {
                mnuMainMenu.Items.Add(Menu6);
            }
            else if (i == 7)
            {
                mnuMainMenu.Items.Add(Menu7);
            }
            else if (i == 8)
            {
                mnuMainMenu.Items.Add(Menu8);
            }
            else if (i == 9)
            {
                mnuMainMenu.Items.Add(Menu9);
            }
            //else if (i == 10)
            //{
            //    mnuMainMenu.Items.Add(Menu10);
            //}
            else
            {
            }
            //Loading All Menus in MasterPage
            //mnuMainMenu.Items.Add(Menu1);
            //mnuMainMenu.Items.Add(Menu2);
            //mnuMainMenu.Items.Add(Menu3);
            //mnuMainMenu.Items.Add(Menu4);
            //mnuMainMenu.Items.Add(Menu5);
            //mnuMainMenu.Items.Add(Menu6);
            //mnuMainMenu.Items.Add(Menu7);
            //mnuMainMenu.Items.Add(Menu8);
            //mnuMainMenu.Items.Add(Menu9);
        }

    }

//        private void LoadMenu(DataTable dtMenu)
//        {
//            foreach (DataRow dr in dtMenu.Rows)
//            {
//                WMainMenu = dr["MainMenu"].ToString();
//                WSubMenu = dr["SubMenu"].ToString();
//                WMainSubMenu = WMainMenu + WSubMenu;
//                #region NewMainMenu
//                if (MainMenu != dr["MainMenu"].ToString()) // This is a new menu  //Add MainMenu Item
//                {
//                    MenuCount = MenuCount + 1;
//                    LoadMainMenuName(MenuCount, WMainMenu);   // Load MainMenu Name Based on MenuCount
//                    if (WMainSubMenu != WMainMenu) // There is a submenu item in this main menu
//                    {
//                        MenuItem Sub = new MenuItem();
//                        Sub.Text = WSubMenu;
//                        foreach (DataRow drSubTrans in dtMenu.Select("MainMenu ='" + WMainMenu + "' and SubMenu = '" + WSubMenu + "'"))
//                        {
//                            MenuItem SubSubMenu = new MenuItem();
//                            SubSubMenu.Text = drSubTrans["ChildMenu"].ToString();
//                            SubSubMenu.NavigateUrl = drSubTrans["ProgramAccessPath"].ToString();
//                            Sub.ChildItems.Add(SubSubMenu);
//                        }
//                        MainMenu = WMainMenu;
//                        MainSubMenu = WMainSubMenu;
//                        LoadSubMenu(MenuCount, Sub); // Load SubMenu Under the MainMenu Depending on MenuCount 
//                    }
//                    else //There's no SubMenu hence the submenu becomes the child menu for hyper linking
//                    {
//                        foreach (DataRow drSubTrans in dtMenu.Select("MainMenu = '" + WMainMenu + "'"))
//                        {
//                            MenuItem SubSubMenu = new MenuItem();
//                            SubSubMenu.Text = drSubTrans["ChildMenu"].ToString();
//                            SubSubMenu.NavigateUrl = drSubTrans["ProgramAccessPath"].ToString();
//                            LoadSubMenu(MenuCount, SubSubMenu); // Load SubSubMenu Under the MainMenu Depending on MenuCount
//                        }
//                        MainMenu = WMainMenu;
//                        MainSubMenu = WMainSubMenu;
//                    }
//                }
//                #endregion
//                #region Submenu
//                else // MainMenu Remains Same
//                {
//                    //If there is a new submenu for same main menu add it else SKIP
//                    if (MainSubMenu != WMainSubMenu) // There is a new Submenu hence proceed
//                    {
//                        if (WMainSubMenu != WMainMenu) // There is a submenu item in this main menu
//                        {
//                            MenuItem Sub = new MenuItem();
//                            Sub.Text = WSubMenu;
//                            foreach (DataRow drSub in dtMenu.Select("MainMenu ='" + WMainMenu + "' and SubMenu = '" + WSubMenu + "'"))
//                            {
//                                MenuItem SubSubMenu = new MenuItem();
//                                SubSubMenu.Text = drSub["ChildMenu"].ToString();
//                                SubSubMenu.NavigateUrl = drSub["ProgramAccessPath"].ToString();
//                                Sub.ChildItems.Add(SubSubMenu);
//                            }
//                            MainMenu = WMainMenu;
//                            MainSubMenu = WMainSubMenu;
//                            LoadSubMenu(MenuCount, Sub); // Load SubMenu Under the MainMenu Depending on MenuCount
//                        }
//                        else  // There is no submenu item in this main menu
//                        {
//                            foreach (DataRow drSub in dtMenu.Select("MainMenu = '" + WMainMenu + "'"))
//                            {
//                                MenuItem SubSubMenu = new MenuItem();
//                                SubSubMenu.Text = drSub["ChildMenu"].ToString();
//                                SubSubMenu.NavigateUrl = drSub["ProgramAccessPath"].ToString();
//                                LoadSubMenu(MenuCount, SubSubMenu); // Load SubSubMenu Under the MainMenu Depending on MenuCount  
//                            }
//                            MainMenu = WMainMenu;
//                            MainSubMenu = WMainSubMenu;
//                        }
//                    }
//                    else
//                    {
//                        //Skip
//                    }
//                }
//#endregion
//            }
          
//            //Loading All Menus in MasterPage
//            mnuMainMenu.Items.Add(Menu1);
//            mnuMainMenu.Items.Add(Menu2);
//            mnuMainMenu.Items.Add(Menu3);
//            mnuMainMenu.Items.Add(Menu4);
//            mnuMainMenu.Items.Add(Menu5);
//            mnuMainMenu.Items.Add(Menu6);
//            mnuMainMenu.Items.Add(Menu7);
//            mnuMainMenu.Items.Add(Menu8);
      
//        }
   #endregion
    protected void lnkbtnLogout_Click(object sender, EventArgs e)
    {
        //LogofDateTime = Bus.GetServerDate();
        //Bus.UpdateUserLogin(HitCounter, LogofDateTime);
        //dtMenu.Clear();
        //Response.Redirect("Login.aspx");
    }
    protected void Collapse_Click(object sender, EventArgs e)
    {
        Collapse();
    }
    private void Collapse()
    {
        if (LnkCollapse.Text == "Menu -")
        {
            Panel1.Visible = false;
            LnkCollapse.Text = "Menu +";
            
        }
        else
        {
            Panel1.Visible = true;
            LnkCollapse.Text = "Menu -";
        }
    }
    #endregion
    #region Methods
 
    public void LoadMainMenuName(int MenuCount, string MainMenuName)
    {
        if (MenuCount == 1)
        {
            Menu1.Text = MainMenuName;
        }
        else if (MenuCount == 2)
        {
            Menu2.Text = MainMenuName;
        }
        else if (MenuCount == 3)
        {
            Menu3.Text = MainMenuName;
        }
        else if (MenuCount == 4)
        {
            Menu4.Text = MainMenuName;
        }
        else if (MenuCount == 5)
        {
            Menu5.Text = MainMenuName;
        }
        else if (MenuCount == 6)
        {
            Menu6.Text = MainMenuName;
        }
        else if (MenuCount == 7)
        {
            Menu7.Text = MainMenuName;
        }
        else if (MenuCount == 8)
        {
            Menu8.Text = MainMenuName;
        }
        else if (MenuCount == 9)
        {
            Menu9.Text = MainMenuName;
        }
    }
    //This Method is to Load SubMenu into MainMenu
    public void LoadSubMenu(int MenuCount, MenuItem Sub)
    {
        if (MenuCount == 1)
        {
            Menu1.ChildItems.Add(Sub);

        }
        else if (MenuCount == 2)
        {
            Menu2.ChildItems.Add(Sub);

        }
        else if (MenuCount == 3)
        {
            Menu3.ChildItems.Add(Sub);

        }
        else if (MenuCount == 4)
        {
            Menu4.ChildItems.Add(Sub);

        }
        else if (MenuCount == 5)
        {
            Menu5.ChildItems.Add(Sub);

        }
        else if (MenuCount == 6)
        {
            Menu6.ChildItems.Add(Sub);

        }
        else if (MenuCount == 7)
        {
            Menu7.ChildItems.Add(Sub);

        }
        else if (MenuCount == 8)
        {
            Menu8.ChildItems.Add(Sub);

        }
        else if (MenuCount == 9) //scs 160417 to include 9th main menu
        {
            Menu9.ChildItems.Add(Sub);

        }
    }
    protected void lnkLogOut_Click(object sender, EventArgs e)
    {
        LoginInfoMsg Login=new LoginInfoMsg();
        Login.UserName=AccessBaseClass.EmployeeCode;
        Login.UserSessionId=AccessBaseClass.UserSessionId;
        Bus.UpdateUserLogoffInfo(Login);
        Session.Clear();
        Session.RemoveAll();
        Response.Redirect("~/Login.aspx");
    }
    protected void lnkHome_Click(object sender, EventArgs e)
    {
       Response.Redirect("~/Default.aspx");
    }
    #endregion
}

using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Exports a gridview to excel
/// </summary>
public class GridViewExportUtil
{
    /// <summary>
    public GridViewExportUtil()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    /// </summary>
    /// <param name="fileName"></param>
    /// <param name="gv"></param>
    public static void Export(string fileName, GridView gv)
    {
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.AddHeader(
            "content-disposition", string.Format("attachment; filename={0}", fileName));
        HttpContext.Current.Response.ContentType = "application/ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            using (HtmlTextWriter htw = new HtmlTextWriter(sw))
            {
                //  Create a table to contain the grid
                Table table = new Table();

                //  include the gridline settings
                table.GridLines = gv.GridLines;

                //  add the header row to the table
                if (gv.HeaderRow != null)
                {
                    GridViewExportUtil.PrepareControlForExport(gv.HeaderRow);
                    table.Rows.Add(gv.HeaderRow);
                }

                //  add each of the data rows to the table
                foreach (GridViewRow row in gv.Rows)
                {
                    GridViewExportUtil.PrepareControlForExport(row);
                    table.Rows.Add(row);
                }

                //  add the footer row to the table
                if (gv.FooterRow != null)
                {
                    GridViewExportUtil.PrepareControlForExport(gv.FooterRow);
                    table.Rows.Add(gv.FooterRow);
                }

                //  render the table into the htmlwriter
                table.RenderControl(htw);

                //  render the htmlwriter into the response
                HttpContext.Current.Response.Write(sw.ToString());
                HttpContext.Current.Response.End();
            }
        }
    }

    public static void Export(string fileName, DataGrid gv)
    {
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.AddHeader(
            "content-disposition", string.Format("attachment; filename={0}", fileName));
        HttpContext.Current.Response.ContentType = "application/ms-excel";

        using (StringWriter sw = new StringWriter())
        {
            using (HtmlTextWriter htw = new HtmlTextWriter(sw))
            {
                //  Create a table to contain the grid
                Table table = new Table();

                //  include the gridline settings
                table.GridLines = gv.GridLines;

                TableRow tabHeaderRow = new TableRow();
                TableRow tabFooterRow = new TableRow();
                    

                foreach (DataGridColumn dgr in gv.Columns)
                {
                    if (dgr.Visible == true)
                    {
                        TableCell tabHdr = new TableCell();
                        tabHdr.Text = dgr.HeaderText;
                        tabHeaderRow.Cells.Add(tabHdr);
                        tabHeaderRow.BackColor = System.Drawing.Color.DarkGray;
                        //
                        TableCell tabFtr = new TableCell();
                        tabFtr.Text = dgr.FooterText;
                        tabFooterRow.Cells.Add(tabFtr);
                        tabHeaderRow.BackColor = System.Drawing.Color.DarkGray;
                    }
                }

                //  add the header row to the table
                if (tabHeaderRow != null)
                {
                    GridViewExportUtil.PrepareControlForExport(tabHeaderRow);
                    table.Rows.Add(tabHeaderRow);
                }
                    
                //  add each of the data rows to the table

                foreach (DataGridItem row in gv.Items)
                {
                    for (int i = gv.Columns.Count - 1; i >= 0; i--)
                    {
                        if (gv.Columns[i].Visible == false)
                        {
                            row.Cells.RemoveAt(i);
                        }
                    }
                    GridViewExportUtil.PrepareControlForExport(row);
                    table.Rows.Add(row);
                }
                //  add the footer row to the table
                if (tabFooterRow != null)
                {
                    GridViewExportUtil.PrepareControlForExport(tabFooterRow);
                    table.Rows.Add(tabFooterRow);
                }

                //  render the table into the htmlwriter
                table.RenderControl(htw);
                //  render the htmlwriter into the response
                HttpContext.Current.Response.Write(sw.ToString());
                HttpContext.Current.Response.End();
            }
        }
    }

    /// <summary>
    /// Replace any of the contained controls with literals
    /// </summary>
    /// <param name="control"></param>
    private static void PrepareControlForExport(Control control)
    {
        for (int i = 0; i < control.Controls.Count; i++)
        {
            Control current = control.Controls[i];
            if (current is LinkButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as LinkButton).Text));
            }
            else if (current is ImageButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as ImageButton).AlternateText));
            }
            else if (current is HyperLink)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as HyperLink).Text));
            }
            else if (current is DropDownList)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as DropDownList).SelectedItem.Text));
            }
            else if (current is CheckBox)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as CheckBox).Checked ? "True" : "False"));
            }
            else if (current is Image)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as Image).AlternateText));
            }

            if (current.HasControls())
            {
                GridViewExportUtil.PrepareControlForExport(current);
            }
        }
    }
}


